/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookintroductionteller;

/**
 *
 * @author QQQQ
 */
public class BookIntroductionTeller {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       // MDIForm mdi = new MDIForm();
        //mdi.show();
        Login log = new Login();
        log.show();
    }
    
}
